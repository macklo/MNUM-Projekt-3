function [ y ] = f( x )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    y = -1.65 + 0.3*x - x*(exp(1))^(-x);
end

